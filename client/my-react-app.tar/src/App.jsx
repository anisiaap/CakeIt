
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import NavBar from './components/NavBar.jsx';
import HomePage from './pages/HomePage.jsx';
import BakeryDetailsPage from './pages/BakeryDetailsPage.jsx';
import CartPage from './pages/CartPage.jsx';
// Import other pages as needed...

function App() {
    return (
        <Router>
            <NavBar />
            <Switch>
                <Route path="/" exact component={HomePage} />
                <Route path="/bakery-details" component={BakeryDetailsPage} />
                <Route path="/cart" component={CartPage} />
                {/* Additional routes for other pages */}
            </Switch>
        </Router>
    );
}

export default App;
