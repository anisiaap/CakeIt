
import React from 'react';
import { useNavigate } from 'react-router-dom';

function LoginPage() {
    const history = useNavigate();

    return (
        <div>
            <h1>Log In</h1>
            <p>This is the Log In page. Placeholder for interactive elements based on the SVG layout.</p>
            <button onClick={() => navigate('/home')}>Go to Home Page</button>
            <br/>
        </div>
    );
}

export default LoginPage;
