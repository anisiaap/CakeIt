
import React from 'react';
import { useNavigate } from 'react-router-dom';

function HomePage() {
    const history = useNavigate();

    return (
        <div>
            <h1>Home Page</h1>
            <p>This is the Home Page page. Placeholder for interactive elements based on the SVG layout.</p>
            <button onClick={() => navigate('/bakery-details')}>Go to Bakery Details</button>
            <br/>
        </div>
    );
}

export default HomePage;
